import React, { useState } from 'react';
import {
  KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, TextInputProps, View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useBooks } from '../context/BooksContext';
import AppButton from '../components/AppButton';
import { BookInput, Category, RootStackParamList } from '../types';
import { CATEGORIES, colors, font, spacing } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'BookForm'>;
type FieldKey = 'title' | 'author' | 'year' | 'quantity';
type Errors = Partial<Record<FieldKey, string>>;

export default function BookFormScreen({ route, navigation }: Props) {
  const id = route.params?.id;
  const { books, addBook, updateBook } = useBooks();
  const editing = books.find(b => b.id === id);

  const [title, setTitle] = useState<string>(editing?.title ?? '');
  const [author, setAuthor] = useState<string>(editing?.author ?? '');
  const [category, setCategory] = useState<Category>(editing?.category ?? CATEGORIES[0]);
  const [year, setYear] = useState<string>(editing ? String(editing.year) : '');
  const [quantity, setQuantity] = useState<string>(editing ? String(editing.quantity) : '');
  const [errors, setErrors] = useState<Errors>({});

  const validate = (): boolean => {
    const e: Errors = {};
    const thisYear = new Date().getFullYear();
    if (!title.trim()) e.title = 'Tên sách không được để trống';
    if (!author.trim()) e.author = 'Tác giả không được để trống';
    const y = Number(year);
    if (!year.trim() || !Number.isInteger(y) || y < 1900 || y > thisYear)
      e.year = `Năm phải là số từ 1900 đến ${thisYear}`;
    const qn = Number(quantity);
    if (!quantity.trim() || !Number.isInteger(qn) || qn <= 0) e.quantity = 'Số lượng phải là số nguyên > 0';
    else if (editing && qn < editing.borrowed)
      e.quantity = `Không nhỏ hơn số cuốn đang mượn (${editing.borrowed})`;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = () => {
    if (!validate()) return;
    const data: BookInput = {
      title: title.trim(), author: author.trim(), category,
      year: Number(year), quantity: Number(quantity),
    };
    if (editing && id) updateBook(id, data);
    else addBook(data);
    navigation.goBack();
  };

  const field = (
    label: string, key: FieldKey, value: string, setter: (t: string) => void, props: TextInputProps = {},
  ) => (
    <View style={{ marginBottom: spacing.md }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, errors[key] ? styles.inputError : null]}
        value={value}
        onChangeText={setter}
        {...props}
      />
      {errors[key] ? <Text style={styles.error}>{errors[key]}</Text> : null}
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['bottom', 'left', 'right']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: spacing.md }} keyboardShouldPersistTaps="handled">
          {field('Tên sách *', 'title', title, setTitle)}
          {field('Tác giả *', 'author', author, setAuthor)}
          <Text style={styles.label}>Thể loại</Text>
          <View style={styles.row}>
            {CATEGORIES.map(c => (
              <Pressable key={c} onPress={() => setCategory(c)} style={[styles.chip, category === c && styles.chipActive]}>
                <Text style={{ color: category === c ? '#fff' : colors.text, fontSize: font.small }}>{c}</Text>
              </Pressable>
            ))}
          </View>
          {field('Năm xuất bản', 'year', year, setYear, { keyboardType: 'numeric', maxLength: 4 })}
          {field('Số lượng', 'quantity', quantity, setQuantity, { keyboardType: 'numeric' })}
          <AppButton title={editing ? 'Lưu thay đổi' : 'Thêm sách'} onPress={save} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  label: { fontSize: font.body, fontWeight: '600', color: colors.text, marginBottom: 6 },
  input: {
    backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: 10,
    paddingHorizontal: 12, fontSize: font.body,
  },
  inputError: { borderColor: colors.danger },
  error: { color: colors.danger, fontSize: font.small, marginTop: 4 },
  row: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: spacing.md },
  chip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#fff',
    borderWidth: 1, borderColor: colors.border, marginRight: spacing.sm, marginBottom: spacing.sm,
  },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
});
