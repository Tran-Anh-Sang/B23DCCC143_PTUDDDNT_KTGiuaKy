import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useBooks } from '../context/BooksContext';
import BookCard from '../components/BookCard';
import AppButton from '../components/AppButton';
import { Book, RootStackParamList } from '../types';
import { CATEGORIES, colors, font, spacing } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'BookList'>;
const FILTERS: string[] = ['Tất cả', ...CATEGORIES];

export default function BookListScreen({ navigation }: Props) {
  const { books, loaded, deleteBook } = useBooks();
  const [q, setQ] = useState<string>('');
  const [cat, setCat] = useState<string>('Tất cả');

  const data = useMemo(() => {
    const k = q.trim().toLowerCase();
    return books.filter(
      b =>
        (cat === 'Tất cả' || b.category === cat) &&
        (b.title.toLowerCase().includes(k) || b.author.toLowerCase().includes(k)),
    );
  }, [books, q, cat]);

  const totalBorrowed = books.reduce((s, b) => s + b.borrowed, 0);

  const confirmDelete = (b: Book) => {
    if (b.borrowed > 0) {
      Alert.alert('Không thể xoá', 'Sách đang có người mượn.');
      return;
    }
    Alert.alert('Xoá sách', `Xoá "${b.title}"?`, [
      { text: 'Huỷ', style: 'cancel' },
      { text: 'Xoá', style: 'destructive', onPress: () => deleteBook(b.id) },
    ]);
  };

  if (!loaded) return <ActivityIndicator style={{ flex: 1 }} color={colors.primary} />;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.h1}>Thư viện</Text>
          <Text style={styles.stat}>{books.length} đầu sách • {totalBorrowed} cuốn đang mượn</Text>
        </View>
        <AppButton title="+ Thêm sách" onPress={() => navigation.navigate('BookForm')} />
      </View>

      <TextInput
        style={styles.search}
        placeholder="Tìm theo tên sách hoặc tác giả..."
        value={q}
        onChangeText={setQ}
      />

      <View style={styles.filters}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={FILTERS}
          keyExtractor={i => i}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => setCat(item)}
              style={[styles.chip, cat === item && styles.chipActive]}>
              <Text style={[styles.chipText, cat === item && { color: '#fff' }]}>{item}</Text>
            </Pressable>
          )}
        />
      </View>

      <FlatList
        data={data}
        keyExtractor={b => b.id}
        contentContainerStyle={{ padding: spacing.md, flexGrow: 1 }}
        ListEmptyComponent={<Text style={styles.empty}>Không có sách nào phù hợp</Text>}
        renderItem={({ item }) => (
          <BookCard
            book={item}
            onPress={() => navigation.navigate('BookDetail', { id: item.id })}
            onLongPress={() => confirmDelete(item)}
          />
        )}
      />
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: spacing.md },
  h1: { fontSize: 24, fontWeight: '800', color: colors.text },
  stat: { fontSize: font.small, color: colors.sub, marginTop: 2 },
  search: {
    backgroundColor: '#fff', marginHorizontal: spacing.md, borderRadius: 10, paddingHorizontal: 12,
    borderWidth: 1, borderColor: colors.border, fontSize: font.body,
  },
  filters: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2 },
  chip: {
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#fff',
    borderWidth: 1, borderColor: colors.border, marginRight: spacing.sm,
  },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.text, fontSize: font.small },
  empty: { textAlign: 'center', color: colors.sub, marginTop: 40, fontSize: font.body },
});
