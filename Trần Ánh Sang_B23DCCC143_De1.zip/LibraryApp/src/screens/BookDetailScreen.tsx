import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useBooks } from '../context/BooksContext';
import AppButton from '../components/AppButton';
import { RootStackParamList } from '../types';
import { colors, font, spacing } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'BookDetail'>;

function InfoRow({ label, value }: { label: string; value: string | number }) {
  return (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );
}

export default function BookDetailScreen({ route, navigation }: Props) {
  const { books, changeBorrowed } = useBooks();
  const book = books.find(b => b.id === route.params.id);
  if (!book) return null;
  const left = book.quantity - book.borrowed;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['bottom', 'left', 'right']}>
      <ScrollView contentContainerStyle={{ padding: spacing.md }}>
        <View style={styles.card}>
          <Text style={styles.title}>{book.title}</Text>
          <InfoRow label="Tác giả" value={book.author} />
          <InfoRow label="Thể loại" value={book.category} />
          <InfoRow label="Năm xuất bản" value={book.year} />
          <InfoRow label="Tổng số cuốn" value={book.quantity} />
          <InfoRow label="Đang mượn" value={book.borrowed} />
          <InfoRow label="Còn lại" value={left === 0 ? 'Hết sách' : left} />
        </View>
        <View style={styles.actions}>
          <AppButton style={{ flex: 1, marginRight: spacing.sm }} title="Cho mượn" disabled={left === 0}
            onPress={() => changeBorrowed(book.id, 1)} />
          <AppButton style={{ flex: 1 }} title="Nhận trả" color={colors.success} disabled={book.borrowed === 0}
            onPress={() => changeBorrowed(book.id, -1)} />
        </View>
        <AppButton title="Sửa thông tin" color={colors.sub}
          onPress={() => navigation.navigate('BookForm', { id: book.id })} />
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card, borderRadius: 12, padding: spacing.md, elevation: 3,
    shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, shadowOffset: { width: 0, height: 2 },
    marginBottom: spacing.md,
  },
  title: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: spacing.md },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  label: { color: colors.sub, fontSize: font.body },
  value: { color: colors.text, fontSize: font.body, fontWeight: '600' },
  actions: { flexDirection: 'row', marginBottom: spacing.md },
});
