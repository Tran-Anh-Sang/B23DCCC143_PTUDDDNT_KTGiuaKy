import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Book } from '../types';
import { colors, font, spacing } from '../theme';

interface Props {
  book: Book;
  onPress: () => void;
  onLongPress: () => void;
}

export default function BookCard({ book, onPress, onLongPress }: Props) {
  const left = book.quantity - book.borrowed;
  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.8 }]}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title} numberOfLines={2}>{book.title}</Text>
        <Text style={styles.sub}>{book.author}</Text>
        <Text style={styles.sub}>{book.category}</Text>
      </View>
      <View style={styles.right}>
        {left === 0 ? (
          <Text style={styles.out}>Hết sách</Text>
        ) : (
          <Text style={styles.left}>Còn {left}</Text>
        )}
      </View>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: {
    flexDirection: 'row', backgroundColor: colors.card, borderRadius: 12, padding: spacing.md,
    marginBottom: spacing.sm + 4, elevation: 3, shadowColor: '#000', shadowOpacity: 0.1,
    shadowRadius: 4, shadowOffset: { width: 0, height: 2 },
  },
  title: { fontSize: font.title, fontWeight: '700', color: colors.text, marginBottom: 4 },
  sub: { fontSize: font.small, color: colors.sub },
  right: { justifyContent: 'center', marginLeft: spacing.sm },
  out: { color: colors.danger, fontWeight: '700', fontSize: font.body },
  left: { color: colors.success, fontWeight: '600', fontSize: font.body },
});
