import React, { createContext, ReactNode, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Book, BookInput } from '../types';

const KEY = 'BOOKS_V1';
const SEED: Book[] = [
  { id: '1', title: 'Cấu trúc dữ liệu và giải thuật', author: 'Nguyễn Văn A', category: 'Giáo trình', year: 2018, quantity: 5, borrowed: 2 },
  { id: '2', title: 'Nhà giả kim', author: 'Paulo Coelho', category: 'Tiểu thuyết', year: 2013, quantity: 3, borrowed: 3 },
  { id: '3', title: 'Lược sử thời gian', author: 'Stephen Hawking', category: 'Khoa học', year: 2000, quantity: 4, borrowed: 0 },
  { id: '4', title: 'Dế Mèn phiêu lưu ký', author: 'Tô Hoài', category: 'Thiếu nhi', year: 2010, quantity: 6, borrowed: 1 },
  { id: '5', title: 'Lập trình di động', author: 'Trần Văn B', category: 'Giáo trình', year: 2022, quantity: 2, borrowed: 0 },
];

interface BooksContextType {
  books: Book[];
  loaded: boolean;
  addBook: (b: BookInput) => void;
  updateBook: (id: string, d: BookInput) => void;
  deleteBook: (id: string) => void;
  changeBorrowed: (id: string, delta: number) => void;
}

const Ctx = createContext<BooksContextType | undefined>(undefined);

export const useBooks = (): BooksContextType => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useBooks phải nằm trong BooksProvider');
  return c;
};

export function BooksProvider({ children }: { children: ReactNode }) {
  const [books, setBooks] = useState<Book[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        setBooks(raw ? (JSON.parse(raw) as Book[]) : SEED);
      } catch {
        setBooks(SEED);
      }
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(KEY, JSON.stringify(books)).catch(() => {});
  }, [books, loaded]);

  const addBook = (b: BookInput) =>
    setBooks(p => [{ ...b, id: Date.now().toString(), borrowed: 0 }, ...p]);
  const updateBook = (id: string, d: BookInput) =>
    setBooks(p => p.map(b => (b.id === id ? { ...b, ...d } : b)));
  const deleteBook = (id: string) => setBooks(p => p.filter(b => b.id !== id));
  const changeBorrowed = (id: string, delta: number) =>
    setBooks(p => p.map(b => (b.id === id ? { ...b, borrowed: b.borrowed + delta } : b)));

  return (
    <Ctx.Provider value={{ books, loaded, addBook, updateBook, deleteBook, changeBorrowed }}>
      {children}
    </Ctx.Provider>
  );
}
