import { Category } from './types';

export const colors = {
  primary: '#2F5D8A', bg: '#F4F6F9', card: '#FFFFFF', text: '#1B1F24',
  sub: '#6B7280', danger: '#D32F2F', disabled: '#B8BDC4', border: '#D5DAE0', success: '#2E7D32',
};
export const spacing = { sm: 8, md: 16, lg: 24 };
export const font = { title: 18, body: 15, small: 13 };
export const CATEGORIES: Category[] = ['Giáo trình', 'Tiểu thuyết', 'Khoa học', 'Thiếu nhi'];
