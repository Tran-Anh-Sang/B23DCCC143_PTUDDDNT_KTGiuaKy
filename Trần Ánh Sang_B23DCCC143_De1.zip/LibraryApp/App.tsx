import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { BooksProvider } from './src/context/BooksContext';
import BookListScreen from './src/screens/BookListScreen';
import BookFormScreen from './src/screens/BookFormScreen';
import BookDetailScreen from './src/screens/BookDetailScreen';
import { RootStackParamList } from './src/types';
import { colors } from './src/theme';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" backgroundColor={colors.bg} />
      <BooksProvider>
        <NavigationContainer>
          <Stack.Navigator
            screenOptions={{ headerTintColor: colors.primary, headerStyle: { backgroundColor: colors.bg } }}>
            <Stack.Screen name="BookList" component={BookListScreen} options={{ headerShown: false }} />
            <Stack.Screen
              name="BookForm"
              component={BookFormScreen}
              options={({ route }) => ({ title: route.params?.id ? 'Sửa sách' : 'Thêm sách' })}
            />
            <Stack.Screen name="BookDetail" component={BookDetailScreen} options={{ title: 'Chi tiết sách' }} />
          </Stack.Navigator>
        </NavigationContainer>
      </BooksProvider>
    </SafeAreaProvider>
  );
}
